from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Trader)
admin.site.register(Referral)
admin.site.register(Visits)
admin.site.register(Wallet)
admin.site.register(Transaction)
admin.site.register(Notification)
admin.site.register(Profit)
